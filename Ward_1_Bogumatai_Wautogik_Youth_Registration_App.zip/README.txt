WARD ONE (1) BOGUMATAI–WAUTOGIK YOUTH REGISTRATION APP

Files:
- index.html — the complete app
- manifest.json — Android install information

HOW TO USE:
1. Extract the ZIP file.
2. Open index.html in a browser to test the form.
3. For an Android home-screen app, the folder should be hosted on a secure HTTPS web address.
4. Registrations are saved locally in the browser on the device.
5. Use “Export CSV” regularly to back up the registrations.

IMPORTANT:
This version is deliberately free and does not require a paid app-builder account. It does not automatically send data to Google Sheets. A later version can be connected to a Google Sheet if required.
